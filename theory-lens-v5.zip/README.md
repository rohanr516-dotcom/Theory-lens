# TheoryLens

One-file web app to analyze MusicXML/MIDI, suggest practice ideas, guitar chord options, scale cells, live fretboard highlights, and auto-harmonize melody. Includes metronome and printable practice sheet.

## Run locally
- Open `index.html` in any modern browser.

## Deploy to GitHub Pages
1. Create a new repo, e.g. `theorylens`.
2. Upload **index.html**, **demo.musicxml**, **demo.mid** (or just drag this whole zip and extract).
3. In the repo: Settings → Pages → **Build and deployment** → Source: **Deploy from a branch**.
4. Branch: `main` • Folder: `/root` • Save.
5. Your app will be available at: `https://<your-username>.github.io/theorylens/`.

## Deploy via Netlify (fast)
- Go to https://app.netlify.com/drop and drop `index.html` (and any assets). Netlify will give you a live URL immediately.

## Deploy via Vercel
- `npx vercel` in a folder with `index.html`, accept defaults. It prints a production link like `https://theorylens.vercel.app`.
